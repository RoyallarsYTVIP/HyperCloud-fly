# Fly
/fly で飛行の切り替えが出来ます<br>
[ダウンロード](https://github.com/Nerahikada/Fly/releases/download/2.0.0/Fly_v2.0.0.phar)